<!DOCTYPE html>
<html>
    {{-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"> --}}

    {{-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script> --}}
    <link href="{{asset('css/report.css')}}" rel="stylesheet">

<body>

    {!! $html !!}
</body>

</html>
