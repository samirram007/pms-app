
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h4 class="text-dark">{{ $header_data['title'] }}</h4>

                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right border-0">
                        <li class="breadcrumb-item "><a href="{{ route('employee.dashboard') }}"
                                class="text-active">Dashboard</a></li>
                        <li class="breadcrumb-item active">{{ $header_data['page_name']}}</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
