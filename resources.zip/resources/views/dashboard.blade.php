@extends('layouts.main')
@section('content')
Welcome to the dashboard!
@endsection
